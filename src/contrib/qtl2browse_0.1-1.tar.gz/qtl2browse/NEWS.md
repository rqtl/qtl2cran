## qtl2browse 0.1-1 (2019-05-28)

- A new package.
