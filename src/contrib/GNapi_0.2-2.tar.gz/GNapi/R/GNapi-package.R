#' @keywords internal
#'
#' @section Vignette:
#' * [GNapi user guide](https://kbroman.org/GNapi/GNapi.html)
"_PACKAGE"
