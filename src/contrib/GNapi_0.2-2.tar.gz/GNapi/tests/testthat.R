library(testthat)
library(GNapi)

test_check("GNapi")
