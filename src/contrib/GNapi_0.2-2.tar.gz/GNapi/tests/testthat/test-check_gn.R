context("check_gn")

test_that("check_gn works", {

    expect_equal(check_gn(), "GN says hello.")

})
