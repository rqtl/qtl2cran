#' @name qtl2-internal
#'
#' @title Internal functions
#'
#' @description Functions that are exported and so available to users but not really intended to be used by a typical user.
NULL
