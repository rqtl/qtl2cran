# Determine if a cross is of phase-known type
is_phase_known <-
    function(cross)
{
    .is_phase_known(cross$crosstype)
}
