library(testthat)
test_check("qtlcharts")
