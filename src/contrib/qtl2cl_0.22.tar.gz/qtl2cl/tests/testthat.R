library(testthat)
library(qtl2cl)

test_check("qtl2cl")
