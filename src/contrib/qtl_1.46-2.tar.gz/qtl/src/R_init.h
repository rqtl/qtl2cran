// Register Dynamic Symbols
#ifndef R_INIT_QTL_H
#define R_INIT_QTL_H

void R_init_qtl(DllInfo* info);

#endif // R_INIT_QTL_H
