## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, fig.width = 7, fig.height = 5)

## ------------------------------------------------------------------------
suppressPackageStartupMessages({
  library(qtl2)
  library(qtl2fst)
})

## ------------------------------------------------------------------------
DOex <-
  read_cross2(
    file.path("https://raw.githubusercontent.com/rqtl",
              "qtl2data/master/DOex",
              "DOex.zip"))

## ------------------------------------------------------------------------
pr <- calc_genoprob(DOex, error_prob=0.002)
apr <- genoprob_to_alleleprob(pr)

## ------------------------------------------------------------------------
tmpdir <- tempdir()

## ------------------------------------------------------------------------
fpr <- fst_genoprob(pr, "pr", tmpdir)
fapr <- fst_genoprob(apr, "apr", tmpdir)

## ------------------------------------------------------------------------
scan_apr <- scan1(fapr, DOex$pheno)

## ------------------------------------------------------------------------
find_peaks(scan_apr, DOex$pmap)

## ------------------------------------------------------------------------
plot(scan_apr, DOex$pmap)

## ------------------------------------------------------------------------
coefs <- scan1coef(apr, DOex$pheno)

## ------------------------------------------------------------------------
plot(coefs, DOex$pmap)

## ------------------------------------------------------------------------
plot(coefs, DOex$pmap, scan1_output = scan_apr)

## ------------------------------------------------------------------------
file <- file.path("https://raw.githubusercontent.com/rqtl",
                  "qtl2data/master/DOex",
                  "c2_snpinfo.rds")
tmpfile <- tempfile()
download.file(file, tmpfile, quiet=TRUE)
snpinfo <- readRDS(tmpfile)
unlink(tmpfile)

## ------------------------------------------------------------------------
snpinfo <- index_snps(DOex$pmap, snpinfo)

## ------------------------------------------------------------------------
snppr <- genoprob_to_snpprob(subset(fapr, chr = "2"), snpinfo)

## ------------------------------------------------------------------------
object.size(snppr)

## ------------------------------------------------------------------------
kinship <- calc_kinship(apr, "loco")

## ------------------------------------------------------------------------
fkinship <- calc_kinship(fapr, "loco")

## ------------------------------------------------------------------------
summary(c(kinship[["2"]] - fkinship[["2"]]))

## ------------------------------------------------------------------------
scan_snppr <- scan1(snppr, DOex$pheno, fkinship["2"])

## ------------------------------------------------------------------------
plot(scan_snppr, snpinfo, drop_hilit = 1.5)

## ----clean_up_files, include=FALSE---------------------------------------
unlink(fst_files(fpr))
unlink(fst_files(fapr))

