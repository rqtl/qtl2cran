## ColorBrewer

[ColorBrewer](http://colorbrewer2.org) by Cynthia Brewer

Taken from [d3/lib/colorbrewer](https://github.com/mbostock/d3/tree/master/lib/colorbrewer)

---

[LICENSE](LICENSE)

