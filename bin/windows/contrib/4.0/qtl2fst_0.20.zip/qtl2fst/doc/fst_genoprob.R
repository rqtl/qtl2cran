## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, fig.width = 7, fig.height = 5)

## ---- load_packages------------------------------------------------------
library(qtl2)
library(qtl2fst)

## ---- load_DOex_data-----------------------------------------------------
DOex <- read_cross2("https://raw.githubusercontent.com/rqtl/qtl2data/master/DOex/DOex.zip")

## ---- calc_alleleprob----------------------------------------------------
pr <- calc_genoprob(DOex, error_prob=0.002)
apr <- genoprob_to_alleleprob(pr)

## ----write_fst_db--------------------------------------------------------
tmpdir <- tempdir()
fpr <- fst_genoprob(pr, "pr", tmpdir)
fapr <- fst_genoprob(apr, "apr", tmpdir)

## ----list_files----------------------------------------------------------
list.files(tmpdir)

## ---- names_length_fpr---------------------------------------------------
names(fpr)
length(fpr)

## ----dim_fpr-------------------------------------------------------------
dim(fpr)
str(dimnames(fpr))

## ---- read_chromosome----------------------------------------------------
dim(fapr[["X"]])

## ------------------------------------------------------------------------
dim(fapr$X)

## ----subset_fapr---------------------------------------------------------
dim(subset(fapr, ind=1:20, chr=c("2","3")))

## ----subset_brackets-----------------------------------------------------
dim(fapr[1:20, c("2","3")][["3"]])

## ----other_subsetting----------------------------------------------------
f2 <- fapr[,"2"]
f23 <- fapr[,c("2","3")]
fx <- fapr[,"X"]

## ----select_markers------------------------------------------------------
dim(subset(fapr, mar=1:30))
dim(fapr[ , , dimnames(fapr)$mar$X[1:20]])

## ----cbind_fapr----------------------------------------------------------
newf23 <- cbind(f2,f23)

## ----rbind_fapr----------------------------------------------------------
f23a <- fapr[1:20, c("2","3")]
f23b <- fapr[40:79, c("2","3")]
f23 <- rbind(f23a, f23b)

## ----subset_markers------------------------------------------------------
markers <- dimnames(fapr$X)[[3]][1:10]
dim(fapr[,,markers]$X)

## ----extract_markers_chr_X-----------------------------------------------
markers <- dimnames(fapr$X)[[3]][1:10]
dim(fapr$X[,,markers])

## ----cbind_two_subsets---------------------------------------------------
fapr2 <- fst_genoprob(subset(apr, chr="2"), "aprx", tmpdir)
fapr3 <- fst_genoprob(subset(apr, chr="3"), "aprx", tmpdir)
fapr32 <- cbind(fapr3,fapr2)
dim(fapr32)
list.files(tmpdir)

## ----names_fapr----------------------------------------------------------
names(unclass(fapr))

## ----fapr_fst_path-------------------------------------------------------
unclass(fapr)$fst

## ----ind_chr_mar_pieces--------------------------------------------------
sapply(unclass(fapr)[c("ind","chr","mar")], length)

## ----restore_from_subset-------------------------------------------------
fapr23 <- subset(fapr, chr=c("2","3"))
dim(fapr23)
dim(fst_genoprob_restore(fapr23))

## ----calc_genoprob_time--------------------------------------------------
system.time(pr <- calc_genoprob(DOex, error_prob=0.002))

## ----create_db_time------------------------------------------------------
system.time(fpr <- fst_genoprob(pr, "pr", tmpdir, quiet=TRUE, overwrite=TRUE))

## ----read_db_time--------------------------------------------------------
tmpfile <- tempfile()
saveRDS(pr, file = tmpfile)
size_pr <- file.size(tmpfile) * 1e-6
unlink(tmpfile)

## ----function_to_get_files-----------------------------------------------
fst_size <- function(fst_genoprob)
{
    sum(file.size(fst_files(fst_genoprob))) / 1024^2
}


## ----extract_chr_time----------------------------------------------------
system.time({
  for(i in seq(100))
    tmp <- fpr[["2"]]
})

## ----extract_markers_time------------------------------------------------
markers <- dimnames(fpr)$mar[["2"]][1:50]
system.time({
  for(i in seq(100))
    tmp <- fpr[["2"]]
})

## ----clean_up_files, include=FALSE---------------------------------------
unlink(fst_files(fpr))
unlink(fst_files(fapr))

