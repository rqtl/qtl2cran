## ----knitr_options, include=FALSE----------------------------------------
library(knitr)
opts_chunk$set(fig.width=7, fig.height=4.5,
               dev.args=list(pointsize=16),
               eval=FALSE)

