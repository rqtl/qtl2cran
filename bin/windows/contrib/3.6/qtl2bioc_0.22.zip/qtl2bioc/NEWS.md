## qtl2bioc 0.22 (2020-05-21)

- No actual changes; just keeping in sync with the qtl2 package.


## qtl2bioc 0.20 (2019-06-03)

- Use Markdown for function documentation, throughout


## qtl2bioc 0.16 (2018-07-23)

- No actual changes; just keeping in sync with the qtl2 package.


## qtl2bioc 0.14 (2018-03-09)

- No actual changes; just keeping in sync with the qtl2 package.


## qtl2bioc 0.12 (2018-01-19)

- Again, no actual changes; just keeping in sync with the qtl2 package.


## qtl2bioc 0.10 (2018-01-09)

- No actual changes; just keeping in sync with the qtl2 package.


## qtl2bic 0.8 (2018-01-05)

- First formal release


## qtl2bioc 0.5-3 (2017-11-09)

### Bug fixes

- Small change to `create_ensembl_query_func()` to get it to work with
  the latest version of [GenomicRanges](https://bioconductor.org/packages/release/bioc/html/GenomicRanges.html).
