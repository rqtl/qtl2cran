## Script to grab small ensembl data frame

This directory contains a script, `grab_ensembl.R`, to grab a small
portion of the ensembl gene annotations, to use in examples and tests.
