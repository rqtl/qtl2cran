## GNapi 0.2-2 (2019-05-29)

### Major changes

- Complete re-write due to complete re-write of the API
